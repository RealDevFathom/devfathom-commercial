# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: time-to-first-sale.spec.ts >> admin follows the first-run checklist to the first completed sale
- Location: tests/e2e/time-to-first-sale.spec.ts:100:5

# Error details

```
Error: Required runtime precondition: PHARMACY_FIRST_SALE_INPUT
```

# Test source

```ts
  1   | /**
  2   |  * Fresh-tenant acceptance journey. Every domain write goes through rendered UI.
  3   |  * Run only with the dedicated time-to-first-sale config against an explicitly
  4   |  * authorized, isolated SHARED staging candidate. No seed/SQL/request helpers.
  5   |  *
  6   |  * PHARMACY_FIRST_SALE_INPUT is an operator-owned JSON file matching JourneyInput.
  7   |  * References below must describe real staging evidence, not invented approvals.
  8   |  * The environment must already have a compatible Pharmacy package (including
  9   |  * HR/procurement), confirmed jurisdiction rules, uploads, invite acceptance and
  10  |  * a configured SHARED deployment host. This test cannot manufacture those.
  11  |  */
  12  | import { randomUUID } from 'node:crypto';
  13  | import { readFileSync } from 'node:fs';
  14  | 
  15  | import { expect, type Browser, type Locator, type Page } from '@playwright/test';
  16  | 
  17  | const attestedSteps = [
  18  |   'Organization type',
  19  |   'Legal business',
  20  |   'Launch jurisdiction',
  21  |   'Branches and locations',
  22  |   'Devices and documents',
  23  |   'Readiness and parallel run',
  24  | ] as const;
  25  | 
  26  | type JourneyInput = {
  27  |   environment: 'ISOLATED_SHARED_STAGING';
  28  |   authorizationRef: string;
  29  |   sourceSha: string;
  30  |   deployedSha: string;
  31  |   packageLabel: string;
  32  |   emailDomain: string;
  33  |   colleaguePhone: string;
  34  |   legalName: string;
  35  |   branchAddress: string;
  36  |   branchCity: string;
  37  |   provinceLabel: string;
  38  |   regulatory: {
  39  |     effectiveFrom: string;
  40  |     premisesStorageDescription: string;
  41  |     licenceCategoryLabel: string;
  42  |     licenceNumber: string;
  43  |     licenceValidFrom: string;
  44  |     licenceValidTo: string;
  45  |     licenceEvidencePath: string;
  46  |     permittedScheduleLabels: string[];
  47  |     qualifiedPersonRegistration: string;
  48  |     qualifiedPersonValidFrom: string;
  49  |     qualifiedPersonValidTo: string;
  50  |     qualifiedPersonCoverageRosterRef: string;
  51  |   };
  52  |   supplier: {
  53  |     name: string;
  54  |     legalName: string;
  55  |     licenceType: string;
  56  |     licenceNumber: string;
  57  |     issuingAuthority: string;
  58  |     issuedAt: string;
  59  |     expiresAt: string;
  60  |     evidenceUri: string;
  61  |     verifiedEvidenceRef: string;
  62  |   };
  63  |   receipt: {
  64  |     supplierInvoiceRef: string;
  65  |     warrantyEvidenceRef: string;
  66  |     approvalNote: string;
  67  |   };
  68  |   attestations: Record<(typeof attestedSteps)[number], string>;
  69  | };
  70  | 
  71  | function requiredEnvironment(name: string) {
  72  |   const value = process.env[name];
> 73  |   if (!value?.trim()) throw new Error(`Required runtime precondition: ${name}`);
      |                             ^ Error: Required runtime precondition: PHARMACY_FIRST_SALE_INPUT
  74  |   return value;
  75  | }
  76  | 
  77  | function stagingOrigin(name: string) {
  78  |   const url = new URL(requiredEnvironment(name));
  79  |   if (
  80  |     url.protocol !== 'https:' ||
  81  |     url.username ||
  82  |     url.password ||
  83  |     url.port ||
  84  |     url.pathname !== '/' ||
  85  |     url.search ||
  86  |     url.hash ||
  87  |     /localhost|\.local$|^\d+\.\d+\.\d+\.\d+$/.test(url.hostname)
  88  |   )
  89  |     throw new Error(`${name} must be an explicit isolated HTTPS staging origin.`);
  90  |   return url.origin;
  91  | }
  92  | 
  93  | function input(): JourneyInput {
  94  |   const value: JourneyInput = JSON.parse(
  95  |     readFileSync(requiredEnvironment('PHARMACY_FIRST_SALE_INPUT'), 'utf8')
  96  |   );
  97  |   const requiredPaths = [
  98  |     'authorizationRef',
  99  |     'sourceSha',
  100 |     'deployedSha',
  101 |     'packageLabel',
  102 |     'emailDomain',
  103 |     'colleaguePhone',
  104 |     'legalName',
  105 |     'branchAddress',
  106 |     'branchCity',
  107 |     'provinceLabel',
  108 |     'regulatory.effectiveFrom',
  109 |     'regulatory.premisesStorageDescription',
  110 |     'regulatory.licenceCategoryLabel',
  111 |     'regulatory.licenceNumber',
  112 |     'regulatory.licenceValidFrom',
  113 |     'regulatory.licenceValidTo',
  114 |     'regulatory.licenceEvidencePath',
  115 |     'regulatory.qualifiedPersonRegistration',
  116 |     'regulatory.qualifiedPersonValidFrom',
  117 |     'regulatory.qualifiedPersonValidTo',
  118 |     'regulatory.qualifiedPersonCoverageRosterRef',
  119 |     'supplier.name',
  120 |     'supplier.legalName',
  121 |     'supplier.licenceType',
  122 |     'supplier.licenceNumber',
  123 |     'supplier.issuingAuthority',
  124 |     'supplier.issuedAt',
  125 |     'supplier.expiresAt',
  126 |     'supplier.evidenceUri',
  127 |     'supplier.verifiedEvidenceRef',
  128 |     'receipt.supplierInvoiceRef',
  129 |     'receipt.warrantyEvidenceRef',
  130 |     'receipt.approvalNote',
  131 |   ];
  132 |   for (const path of requiredPaths) {
  133 |     const field = path
  134 |       .split('.')
  135 |       .reduce<unknown>(
  136 |         (node, key) => (node && typeof node === 'object' ? Reflect.get(node, key) : undefined),
  137 |         value
  138 |       );
  139 |     if (typeof field !== 'string' || !field.trim())
  140 |       throw new Error(`Missing runtime input: ${path}`);
  141 |   }
  142 |   if (
  143 |     !Array.isArray(value.regulatory.permittedScheduleLabels) ||
  144 |     !value.regulatory.permittedScheduleLabels.every(
  145 |       (item) => typeof item === 'string' && item.trim()
  146 |     )
  147 |   )
  148 |     throw new Error('Supply the permitted schedule labels from the confirmed jurisdiction.');
  149 |   // Validate without echoing credentials, evidence contents or business details.
  150 |   function nonempty(node: unknown): boolean {
  151 |     if (typeof node === 'string') return node.trim().length > 0;
  152 |     if (Array.isArray(node)) return node.length > 0 && node.every(nonempty);
  153 |     return Boolean(
  154 |       node &&
  155 |       typeof node === 'object' &&
  156 |       Object.values(node).length &&
  157 |       Object.values(node).every(nonempty)
  158 |     );
  159 |   }
  160 |   if (!nonempty(value) || value.environment !== 'ISOLATED_SHARED_STAGING')
  161 |     throw new Error('Provide complete, authorized staging journey inputs.');
  162 |   if (!/^[a-f0-9]{40}$/.test(value.sourceSha) || value.sourceSha !== value.deployedSha)
  163 |     throw new Error(
  164 |       'Operator must verify and supply matching exact source/deployed candidate SHAs.'
  165 |     );
  166 |   for (const step of attestedSteps)
  167 |     if (!value.attestations?.[step]?.trim())
  168 |       throw new Error(`Missing actual evidence for ${step}.`);
  169 |   // Fail before organization creation if the actual upload evidence is absent.
  170 |   readFileSync(value.regulatory.licenceEvidencePath);
  171 |   return value;
  172 | }
  173 | 
```